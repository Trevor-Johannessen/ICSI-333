#include <stdio.h>
#include <string.h>

char *nameOne[]; // player 1's name
char *nameTwo[]; // player 2's name
int loopState = 1; // controls the game loop
int winStatus = 0; // tells if someone has won, 0 if noones won, 1 if someones won
int winPlayer = 0;
int turn = 1; // which players turn it is Player 1 is 1, player 2 is -1
int **board; // connect 4 board I found on google images was 6x7
int width = 7; // the width of the board
int height = 7; // the height of the board + 1


// functions
int setup(); // sets up the game also allocates board
int namePrint(); // prints out the names of the players (this was originally due to testing but I thought it looked nice
int teardown(); // prints DESTROYING THE GAME also frees board
char getInput(int); // gets input, int is what player needs input (whos turn it is)
int update(char); // updates with the input given (char)
int display(); // shows the board eventually rn just shows whats updated
void displayBoard(); // displays the board
int checkWin(); // checks if a player has won
int boardFull(); // checks if the board is full



int main()
{
	
	setup();
	namePrint();
	printf("\n");
	
	while(loopState == 1)
	{
		update(getInput(turn));
		display();

		turn *= -1;
	}
	
	teardown();
	
	return 0;
}


/* 
	I kept having to look up how to spell Initialize, this is easier. 
	Allocates memory for the board and fills it with tiles. 
	The board is 1 taller than visible to put a series of blockers at the bottom so that
	instead of checking if we're out of bounds, we can reuse the free space check when
	determining where a piece will fall
	Also takes players name inputs
*/
int setup() 
{
	board = malloc(sizeof(int*)*height);
	for(int i = 0; i < height; i++)
		board[i] = malloc(sizeof(int) * width);
	for(int i = 0; i < width; i++)
		board[height-1][i] = 3;	
	printf("Setting up the game! \n");
	printf("\n Player 1 Enter Name: \n");
	scanf("%s", nameOne);
	printf("\n Player 2 Enter Name: \n");
	scanf("%s", nameTwo);
	displayBoard();
	return 0;
}



int namePrint() // startup sequence, makes sure everyone knows who they are
{
	printf("Player 1 is: ");
	printf("%s", nameOne);
	printf("\nPlayer 2 is: ");
	printf("%s", nameTwo);
	printf("\n");
}



int teardown() // frees memory when game is over
{
	printf("DESTROYING THE GAME\n\n");
	free(board);
}



char getInput(int player) // valid inputs are A-G and a letter for quitting the game
{
	int validInput = 0;
	char input;
	while(validInput == 0)
	{
		if(player == 1)
			printf("%s please input your row (A-G)\n", nameOne);
		else
			printf("%s please input your row (A-G)\n", nameTwo);
		
		printf("Enter J to exit\n");
		
		scanf("%s", &input);
		printf("\n");
		
		if(((input >= 'A') && (input <= 'G') || (input == 'J')) && (board[0][input-65] == 0))
		{
			validInput = 1;
			printf("You have inputted %d\n", input);
		}
		else
			printf("\nInvalid input, please try again\n");
		
		printf("\n");
		
	}
	return input;
}


// updates the game to place pieces where they should go or check if a player has won
// also checks if board is full
int update(char input) 
{
	int loop = 1;
	int i = 0;
	
	if(input == 'J')
	{
		printf("You've printed J\n");
		loopState = 0;
	}
	else
		while(loop)
		{
			if(board[i][input-65] != 0)// minus 65 from letter input array input is y,x (down then right)
			{
				board[i-1][input-65] = turn;
				loop = 0;
			}
			i++;
		}
	checkWin();
	if(boardFull())
		loopState = 0;

}
// checks if the board is full
int boardFull()
{
	int full = 1;
	for(int i = 0; i < height; i++)
		for(int j = 0; j < width; j++)
			if(board[i][j] == 0)
				full = 0;
	return full;
	
}

// checks if a player has placed 4 pieces next to eachother in any direction

/*
	Uses 4 flags to make sure the check does not go out of bounds
	if its at least 4 spaces in any direction its flag is set to true
	Checks are divided into two main groups involving the vertical flags
	Each group has three statements for vertical left, vertical right, and vertical.
	After the groups are the two horizontal checks
*/
int checkWin()
{
	int clearUp = 0;
	int clearDown = 0;
	int clearLeft = 0;
	int clearRight = 0;
	for(int i = 0; i < height-1; i++)
		for(int j = 0; j < width; j++)
			if(board[i][j] != 0)
			{
				if(i >= 3)
					clearUp = 1;
				if(i <= 1)
					clearDown = 1;
				if(j >= 3)
					clearLeft = 1;
				if(j <=2)
					clearRight = 1;
				
				if(clearUp)
				{
					if(clearLeft)
						if((board[i-1][j-1] == board[i][j]) && (board[i-2][j-2] == board[i][j]) && (board[i-3][j-3] == board[i][j]))
						{
							printf("\nA\n");
							winPlayer = turn;
						}
					if(clearRight)
						if((board[i-1][j+1] == board[i][j]) && (board[i-2][j+2] == board[i][j]) && (board[i-3][j+3] == board[i][j]))
						{
							printf("\nB\n");
							winPlayer = turn;
						}
					if((board[i-1][j] == board[i][j]) && (board[i-2][j] == board[i][j]) && (board[i-3][j] == board[i][j]))
					{
						printf("\nC\n");
						winPlayer = turn;
					}
				}
				
				if(clearDown)
				{
					if(clearLeft)
						if((board[i+1][j-1] == board[i][j]) && (board[i+2][j-2] == board[i][j]) && (board[i+3][j-3] == board[i][j]))
							winPlayer = turn;
					else if(clearRight)
						if((board[i+1][j+1] == board[i][j]) && (board[i+2][j+2] == board[i][j]) && (board[i+3][j+3] == board[i][j]))
							winPlayer = turn;
					else
						if((board[i+1][j] == board[i][j]) && (board[i+2][j] == board[i][j]) && (board[i+3][j] == board[i][j]))
							winPlayer = turn;
				}
				if(clearLeft)
					if((board[i][j-1] == board[i][j]) && (board[i][j-2] == board[i][j]) && (board[i][j-3] == board[i][j]))
							winPlayer = turn;
				if(clearRight)
					if((board[i][j+1] == board[i][j]) && (board[i][j+2] == board[i][j]) && (board[i][j+3] == board[i][j]))
							winPlayer = turn;
				
					
					
				clearUp=0;
				clearDown=0;
				clearLeft=0;
				clearRight=0;
				
				
			}
	
	
	if(winPlayer !=0)
	{
		printf("A Player Has Won\n");
		loopState = 0;
	}
	return 0;
}




/*
	Chooses display based on game state
*/
int display()
{
	
	
	if(winStatus == 1)
	{
		if(turn == 1)
			printf("%s has WON!!!\n", nameOne);
		else
			printf("%s has WON!!!\n", nameTwo);
		
		loopState = 0; 
	}
	else
		displayBoard();
	
}


// displays the board. 
void displayBoard()
{
	
	printf("   A B C D E F G\n");
	for(int i = 0; i < 6; i++)
	{
		printf("  | ");
		for(int j = 0; j < 7; j++)
		{
		if(board[i][j] == 0)
			printf("- ");
		else if(board[i][j] == 1)
			printf("x ");
		else
			printf("o ");
		}
		printf("|\n");
	}
	printf("\n");
	
}
