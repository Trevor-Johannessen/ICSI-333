#include <stdio.h>
#include <string.h>

char *nameOne[]; // player 1's name
char *nameTwo[]; // player 2's name
int loopState = 1; // controls the game loop
int winStatus = 0; // tells if someone has won, 0 if noones won, 1 if someones won
int turn = 1; // which players turn it is Player 1 is 1, player 2 is -1
int board[6][7]; // connect 4 board I found on google images was 6x7

// functions
int setup(); // sets up the game
int namePrint(); // prints out the names of the players (this was originally due to testing but I thought it looked nice
int teardown(); // prints DESTROYING THE GAME
char getInput(int); // gets input, int is what player needs input (whos turn it is)
int update(char); // updates with the input given (char)
int display(); // shows the board eventually rn just shows whats updated

int main()
{
	setup();
	namePrint();
	printf("\n");
	
	while(loopState == 1)
	{
		update(getInput(turn));
		display();

		turn *= -1;
	}
	
	teardown();
	
	return 0;
}

int setup() // I kept having to look up how to spell Initialize, this is easier. 
{
	printf("Setting up the game! \n");
	printf("\n Player 1 Enter Name: \n");
	scanf("%s", nameOne);
	printf("\n Player 2 Enter Name: \n");
	scanf("%s", nameTwo);
	return 0;
}

int namePrint()
{
	printf("Player 1 is: ");
	printf("%s", nameOne);
	printf("\nPlayer 2 is: ");
	printf("%s", nameTwo);
	printf("\n");
}

int teardown()
{
	printf("DESTROYING THE GAME\n\n");
}

char getInput(int player) // valid inputs are A-G and a letter for quitting the game
{
	int validInput = 0;
	char input;
	while(validInput == 0)
	{
		if(player == 1)
			printf("%s please input your row (A-G)\n", nameOne);
		else
			printf("%s please input your row (A-G)\n", nameTwo);
		
		printf("Enter J to exit\n");
		
		scanf("%s", &input);
		printf("\n");
		
		if((input >= 'A') && (input <= 'G') || (input == 'J'))
		{
			validInput = 1;
			printf("You have inputted %c\n", input);
		}
		else
			printf("\nInvalid input, please try again\n");
		
		printf("\n");
		
	}
	return input;
}

int update(char input)
{
	if(input == 'A')
	{
		printf("You've printed A\n");
		winStatus = 1;
	}
	else if(input == 'J')
	{
		printf("You've printed J\n");
		loopState = 0;
	}

}

int display()
{
	if(winStatus == 1)
	{
		if(turn == 1)
			printf("%s has WON!!!\n", nameOne);
		else
			printf("%s has WON!!!\n", nameTwo);
		
		loopState = 0; 
	}
}

